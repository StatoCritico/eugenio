---
name: load-curve
description: Scarica le curve di carico quartorarie dal portale e-distribuzione.it per uno o piu' POD (anche da elenco Excel/CSV), le archivia per POD e produce CODICE_POD.csv / .xlsx / _15min.csv aggiornando solo i dati mancanti. Usa quando l'utente scrive "load_curve", "curva di carico", o chiede consumi quartorari/POD da e-distribuzione. Non per bollette PDF, tariffe o dati GSE.
---

# e-distribuzione - Curva di Carico (multi-POD)

Skill end-to-end per scaricare i consumi quartorari dal Portale Clienti di
e-distribuzione, archiviarli per POD e produrre file di analisi pronti all'uso.
Funziona con un singolo POD o con un elenco da file Excel/CSV.

Flusso: trova cartella di lavoro -> scegli POD -> l'utente fa login + OTP ->
per ogni POD scarica i mesi mancanti (in autonomia) -> archivia i CSV mensili
-> elabora -> CSV orario + Excel + CSV quartorario -> aggiorna data_agg.

**REGOLE FONDAMENTALI**
- Dopo il login non chiedere conferme: procedi in autonomia su tutti i POD.
- **Avanzamento in chat**: a ogni sede completata invia subito un breve
  messaggio con `SendUserMessage` senza fermarti, es.
  `✅ 3/37 SEDE1 (IT001E00000000): mag-ott 2026 scaricati ed elaborati`.
  Sede fallita o incompleta: `⚠️` + motivo, poi passa alla successiva.
- **Password, OTP e CAPTCHA li gestisce sempre l'utente.** Claude non digita
  password e non risolve CAPTCHA: apre la pagina e chiede all'utente di
  completare e scrivere "fatto".
- **Niente chiamate dirette alle API del portale** (es. replay delle richieste
  `aura` / `QueryLoadProfile`): sono bloccate dai controlli di sicurezza. Usa
  solo i pulsanti della pagina (anche cliccati via JavaScript).

---

## Prerequisiti

- **Browser**: estensione Claude in Chrome connessa (`tabs_context_mcp`).
  Il download avviene nella cartella Download di Chrome.
- **Accesso alle cartelle del PC** (Claude desktop, cartelle collegate):
  1. la **cartella di lavoro POD** (contiene `config.json`, `elenco_POD.xlsx`,
     `download/`, `outputs/`)
  2. la cartella **Download** del browser.
  Se non sono collegate, chiedile con `device_request_folder_access`
  (o chiedi all'utente di aggiungerle con "Add folder").
- **Trova la cartella di lavoro**: cerca `config.json` / `elenco_POD.xlsx`
  sotto le cartelle collegate (es. `find $HOME/mnt -maxdepth 4 -name elenco_POD.xlsx`).
  Non assumere un percorso fisso (per esempio `Documents\POD`). Se non la trovi, chiedi.
- **config.json** (nella cartella di lavoro), solo dati non segreti:
  ```json
  {
    "username": "email@esempio.it",
    "login_url": "https://private.e-distribuzione.it/PortaleClienti/s/login/"
  }
  ```
  Se manca, crealo dal template e chiedi all'utente di compilarlo.
  **Non salvare la password nel file**: il login lo fa l'utente (Chrome puo'
  ricordare le credenziali). Se un config esistente contiene `password`,
  non leggerla, non mostrarla e non usarla.

Nei comandi sotto, `$POD` = cartella di lavoro e `$DL` = cartella Download,
come appaiono in `device_bash` (es. `$HOME/mnt/POD`, `$HOME/mnt/Downloads`).

---

## Step 1 - Scegli i POD

Usa `AskUserQuestion`:
- **"Elenco da file (elenco_POD.xlsx)"** nella cartella di lavoro
- **"POD singolo"** (codice breve opzionale, es. `SEDE1 IT001E00000000`)
- **"Elenco da file - altro percorso"**

### File elenco
Colonne: **CODICE**, **POD** (obbligatorie), **data_agg** (opzionale, data
ultimo aggiornamento; vuota = mai aggiornato). `.xlsx` o `.csv`.

Logica:
1. Escludi i POD con `data_agg >= oggi`.
2. Se restano **piu' di 10** POD: ordina per `data_agg` crescente (vuote
   prima), proponi i primi 8 e chiedi conferma con `AskUserQuestion`
   (opzioni: "Si', questi 8" / "Tutti" / "Scegli altri"). Rispetta la scelta.
3. Se ≤ 10: mostra l'elenco e procedi.

### Calcolo dei mesi da scaricare (per POD)
- Archivio raw: `$POD/download/<POD>/curva_<POD>_YYYY-MM.csv`.
- **Mese di partenza = ultimo mese gia' archiviato** (riscaricalo: spesso e'
  parziale, es. scaricato il 20 del mese). Se non c'e' archivio: oggi - 18 mesi.
- **Mese finale = ultimo mese chiuso** (il mese corrente di solito non e'
  disponibile: "misure non disponibili").
- Il portale va indietro al massimo **18 mesi**.

```python
import openpyxl, glob, os
from datetime import date
def plan(base, rows, today=date.today()):
    out = []
    lo = (today.year*12 + today.month - 1) - 18            # limite 18 mesi
    for cod, pod in rows:
        fs = sorted(glob.glob(f"{base}/download/{pod}/curva_{pod}_2*.csv"))
        if fs:
            y, m = map(int, os.path.basename(fs[-1])[-11:-4].split("-"))
            start = y*12 + m - 1
        else:
            start = lo
        start = max(start, lo)
        end = today.year*12 + today.month - 2              # mese precedente
        out.append((cod, pod, start, end))                 # indici mese assoluti
    return out
```

---

## Step 2 - Login (lo fa l'utente)

1. `tabs_context_mcp(createIfEmpty=true)`, salva il tabId.
2. Naviga direttamente a `https://private.e-distribuzione.it/PortaleClienti/s/login/`
   (la home pubblica `www.e-distribuzione.it` e `/it/area-clienti.html` non servono).
3. Scrivi all'utente: *"Ho aperto il login di e-distribuzione nella scheda
   Chrome. Clicca Entra (le credenziali possono essere gia' salvate),
   completa l'OTP e scrivimi 'fatto'."* Poi attendi.
4. Dopo "fatto": screenshot di verifica, deve comparire "benvenuto nella tua
   area riservata" e il riquadro "Ricerca e selezione fornitura".

**Interruzioni durante il lavoro** (fermati, avvisa con ⏸️, riprendi da dove eri):
- **CAPTCHA Imperva** ("Additional security check is required"): chiedi
  all'utente di spuntare la casella e scrivere "fatto".
- **Sessione scaduta** (ricompare la pagina di login, tipicamente dopo
  qualche ora): chiedi di rifare login + OTP.

---

## Step 3 - Download per POD (flusso verificato in produzione)

La pagina curve si apre cosi': Home -> campo **POD** -> "Ricerca e gestisci
forniture" -> link **"Vuoi visualizzare le curve di carico del tuo
contatore?"** -> `/PortaleClienti/s/curvedicarico`. Il POD selezionato e'
legato alla sessione. Nella pagina: 4 select (mese/anno inizio, mese/anno
fine), "Modifica periodo", grafico di **un mese alla volta** con
"Precedente"/"Successivo", e "Scarica il dettaglio del quarto orario" che
scarica **solo il mese visualizzato** come `ExportData_<mese>.csv`.

Vincoli osservati:
- **Periodo massimo: usa blocchi da 3 mesi.** A volte 6 mesi funzionano, ma
  spesso il portale risponde "Si prega di ridurre il periodo di riferimento".
- Il campo POD della home e' in shadow DOM: serve una ricerca "deep".
- Dopo "Modifica periodo" e dopo "Successivo" bisogna attendere il
  caricamento, altrimenti si scarica il mese precedente o nulla.
- Ogni chiamata `javascript_tool` va in timeout dopo ~45 s: avvia la
  procedura senza attendere (salva il risultato in `window.__res`) e
  controllalo dopo.
- `browser_batch` troppo lunghi (>2-3 min) perdono la connessione: un POD per
  batch.

### 3a - Installa la procedura nella pagina (una volta per sessione)
Salvala in `localStorage` cosi' sopravvive ai cambi di pagina:

```js
localStorage.__lc = `(async function(pod,sm,n,sy){
let em=sm+n-1,ey=sy;if(em>12){em-=12;ey+=1;}
const sl=ms=>new Promise(r=>setTimeout(r,ms));
const deep=(sel,root=document)=>{let o=[...root.querySelectorAll(sel)];for(const el of root.querySelectorAll('*'))if(el.shadowRoot)o=o.concat(deep(sel,el.shadowRoot));return o;};
const btn=t=>deep('button').find(b=>b.textContent.trim().includes(t));
if(!location.pathname.includes('curvedicarico')){
  let inp;for(let i=0;i<40;i++){await sl(500);inp=deep('input').find(x=>x.getAttribute('maxlength')==='15');if(inp&&btn('Ricerca e gestisci'))break;}
  if(!inp)return pod+' noinput';
  const set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
  inp.focus();set.call(inp,pod);inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));inp.blur();
  await sl(500);btn('Ricerca e gestisci').click();await sl(2500);
  let lk;for(let i=0;i<30;i++){await sl(500);lk=deep('a').find(a=>a.textContent.includes('visualizzare le curve di carico'));if(lk)break;}
  if(!lk)return pod+' nolink';
  lk.click();for(let i=0;i<40;i++){await sl(500);if(location.pathname.includes('curvedicarico')&&document.querySelectorAll('select').length>=4)break;}
  await sl(3000);
}
const shown=(document.body.innerText.match(/IT001E\\d{8}/)||[''])[0];if(shown!==pod)return pod+' wrongpod:'+shown;
const s=[...document.querySelectorAll('select')];const sv=(i,v)=>{s[i].value=String(v);s[i].dispatchEvent(new Event('change',{bubbles:true}));};
sv(0,sm);sv(1,sy);sv(2,em);sv(3,ey);btn('Modifica periodo').click();
const log=[];await sl(14000);
for(let m=0;m<n;m++){const d=btn('quarto orario');if(!d){log.push('nodl'+m);break;}
  d.click();log.push('dl'+m);await sl(4500);
  if(m<n-1){let x;for(let w=0;w<20;w++){x=btn('Successivo');if(x&&!x.disabled)break;await sl(500);}
    if(!x||x.disabled){log.push('nonext');break;}x.click();await sl(7500);}}
return pod+' '+log.join(',');})`;
```

### 3b - Esegui per ogni POD
Prima annota il timestamp: `device_bash: date +%s` -> `SINCE`.

Un `browser_batch` per POD:
1. `navigate` a `https://private.e-distribuzione.it/PortaleClienti/s/`
2. `javascript_tool`:
   `window.__res='running'; eval(localStorage.__lc)('<POD>',<mese>,3,<anno>).then(r=>window.__res=r).catch(e=>window.__res='ERR '+e); 'started'`
3. 4-5 `wait` da 10 s
4. `javascript_tool`: `for(let i=0;i<40&&window.__res==='running';i++) await new Promise(r=>setTimeout(r,1000)); window.__res`
5. Per i blocchi successivi dello stesso POD (si e' gia' sulla pagina curve,
   niente navigate): `window.__res='running'; eval(localStorage.__lc)('<POD>',<mese>,<n>,<anno>).then(...); await new Promise(r=>setTimeout(r,40000)); window.__res`

Esempio mag-ott 2026: `(pod,5,3,2026)` poi `(pod,8,3,2026)`.
I blocchi possono scavalcare l'anno (es. `(pod,11,3,2025)` = nov 2025 - gen 2026).

Esiti:
- `dl0,dl1,dl2` = ok. `nodl0` = nessuna curva per quel periodo (vedi sotto).
- `nolink` / `wrongpod` / `noinput` = pagina lenta, CAPTCHA o sessione
  scaduta: fai uno screenshot e agisci di conseguenza (ritenta una volta).
- "Si prega di ridurre il periodo" -> usa blocchi piu' piccoli.

Casi speciali:
- **Contatore "non orario"** (scheda fornitura: `Tipologia contatore: 1G`,
  `Orario/Non orario: Non orario`): il link curve non esiste -> `⚠️` e salta.
- **Curva non disponibile** ("Siamo spiacenti le misure non sono al momento
  disponibili") ma totali mensili presenti: archivia i mesi ottenuti, `⚠️`.

### 3c - Archivia i file scaricati (dopo ogni POD)
Script `$HOME/mv2.py` (crealo una volta). Prende i nuovi `ExportData_*.csv`
in ordine di tempo, ricava mese/anno dalla **prima riga dati** (il nome del
file non ha l'anno ed e' a volte sbagliato), li copia in
`download/<POD>/curva_<POD>_YYYY-MM.csv` e sposta gli originali in
`$DL/_to_delete/` (in quella cartella non si puo' cancellare: l'utente la
svuota). Se manca un file (download perso, capita) lo segnala.

```python
# uso: python3 mv2.py <SINCE> <POD>:<n_file> [<POD2>:<n2> ...]
import sys,os,glob,re,shutil,time
BASE=os.environ.get('POD_DIR'); DL=os.environ.get('DL_DIR')
since=float(sys.argv[1]); groups=[(a.split(':')[0],int(a.split(':')[1])) for a in sys.argv[2:]]
mesi=['gennaio','febbraio','marzo','aprile','maggio','giugno','luglio','agosto','settembre','ottobre','novembre','dicembre']
need=sum(n for _,n in groups)
for _ in range(25):
    files=sorted([f for f in glob.glob(DL+'/ExportData_*.csv') if os.path.getmtime(f)>since],key=os.path.getmtime)
    if len(files)>=need: break
    time.sleep(1)
if len(files)!=need: print('COUNT MISMATCH',len(files),'vs',need,[os.path.basename(f) for f in files]); sys.exit(1)
i=0
for pod,n in groups:
    dst=f'{BASE}/download/{pod}'; os.makedirs(dst,exist_ok=True); out=[]
    for f in files[i:i+n]:
        rows=[l for l in open(f,encoding='utf-8-sig',errors='replace').read().splitlines()[1:] if re.match(r'"?\d{2}/\d{2}/\d{4}',l)]
        if not rows: out.append('EMPTY'); continue
        d=rows[0].strip('"')[:10]; ym=f"{d[6:10]}-{d[3:5]}"
        nm=os.path.basename(f).split('_')[1].split('.')[0].split(' ')[0]
        flag='' if nm not in mesi or mesi.index(nm)+1==int(ym[5:]) else ' !MESE_DIVERSO'
        shutil.copyfile(f,f'{dst}/curva_{pod}_{ym}.csv')
        os.makedirs(DL+'/_to_delete',exist_ok=True); shutil.move(f,f'{DL}/_to_delete/{pod}_{ym}_{os.path.basename(f)}')
        out.append(f'{ym}({len(rows)}){flag}')
    i+=n; print(pod,' '.join(out))
```
Lancio: `POD_DIR=$POD DL_DIR=$DL python3 $HOME/mv2.py $SINCE <POD>:6`.
- Esegui **prima** di avviare il POD successivo (altrimenti i file si mescolano).
- `COUNT MISMATCH`: guarda quali mesi mancano (prima riga dati dei nuovi
  file), archivia quelli arrivati, poi riscarica i mancanti con un blocco
  dedicato (es. `(pod,9,1,2026)`).
- Due file con lo stesso mese (es. due `2026-09`): l'ultimo download era del
  mese precedente non ancora aggiornato -> riscarica il mese mancante.

Subito dopo, elabora il POD (Step 4) e manda il messaggio `✅`.

---

## Step 4 - Elaborazione (dopo ogni POD)

### Output
```
$POD/outputs/
  <codice>_<POD>.csv        -> orario: data;ORA;kWh  ("DD/MM/YYYY 00:00";1..24;valore)
  <codice>_<POD>.xlsx       -> fogli "Orario" + "Riepilogo" mensile
  <codice>_<POD>_15min.csv  -> quartorario wide (1 riga/giorno, 96 colonne)
$POD/download/<POD>/curva_<POD>_YYYY-MM.csv  -> archivio raw dal portale
```
Se gli output esistenti stanno nella radice della cartella di lavoro invece
che in `outputs/`, usa dove si trovano gia'. Senza codice: nome `<POD>`.

### Formato CSV del portale
- Header `Giorno;00:00-00:15;...;23:45-00:00` (97 campi, senza virgolette).
- Righe `"DD/MM/YYYY";"v1";...;"v96";` (virgolette, decimale `,`, `;` finale), LF.
- **Cambio ora legale -> solare** (ultima domenica di ottobre): il giorno ha
  **due righe** con la stessa data: la prima con gli slot 00:00-03:00 (ora
  legale) e poi zeri, la seconda con zeri fino alle 02:00 e poi i valori
  (ora solare). **Vanno sommate**: si ottengono 24 ore con il totale
  giornaliero corretto (l'ora 3 contiene due ore di consumo).
- **Ora solare -> legale** (marzo): una riga, slot 02:00-03:00 a zero. Ok cosi'.

### Script `$HOME/proc.py`
L'archivio raw e' la fonte di verita': i dati nuovi **sovrascrivono** le
stesse chiavi negli output (i mesi riscaricati possono essere rettificati).
Le righe esistenti in formato diverso da `data;ORA;kWh` (es. 1 riga/giorno
con 24 colonne, trovate in vecchi output) vengono scartate: verifica prima
che l'archivio copra lo stesso periodo, e fai una copia in `old/`.

```python
# uso: POD_DIR=$POD python3 proc.py CODICE:POD [CODICE:POD ...]
import glob,re,os,sys
BASE=os.environ['POD_DIR']; OUT=BASE+'/outputs'
def dec(p):
    raw=open(p,'rb').read()
    for e in ('utf-8-sig','cp1252','latin-1'):
        try: return raw.decode(e)
        except: pass
def fnum(v):
    try: return float(v.replace(',','.'))
    except: return 0.0
def fmt(x): return ('%g'%round(x,3)).replace('.',',')
def parse(path):
    """-> {data: [96 float]} con le righe doppie (cambio ora) sommate."""
    ey=int(os.path.basename(path).split('_')[-1][:4]); days={}
    for l in dec(path).splitlines()[1:]:
        c=[x.strip('"') for x in l.strip().rstrip(';').split(';')]
        d=c[0]
        if not re.match(r'\d{2}/\d{2}/\d{4}$',d) or int(d[6:])!=ey: continue
        v=[fnum(x) for x in c[1:97]]+[0.0]*(96-len(c[1:97]))
        days[d]=[a+b for a,b in zip(days[d],v)] if d in days else v
    return days
dk=lambda d:(int(d[6:10]),int(d[3:5]),int(d[0:2]))
def write(p,text):
    tmp=p+'_new_tmp'; open(tmp,'w',encoding='utf-8',newline='\n').write(text); os.replace(tmp,p)
def build_xlsx(hourly,xp):
    from openpyxl import Workbook
    from openpyxl.styles import Font,PatternFill,Alignment
    wb=Workbook(); ws=wb.active; ws.title='Orario'; fill=PatternFill('solid',fgColor='1F4E79')
    for i,h in enumerate(['data','ORA','kWh'],1):
        c=ws.cell(1,i,h); c.fill=fill; c.font=Font(bold=True,color='FFFFFF'); c.alignment=Alignment(horizontal='center')
    for col,w in zip('ABC',(18,6,12)): ws.column_dimensions[col].width=w
    mon={}; mn=['','Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre']
    for (d,h),v in sorted(hourly.items(),key=lambda kv:(dk(kv[0][0]),kv[0][1])):
        ws.append([d+' 00:00',h,v]); m=mon.setdefault((int(d[6:]),int(d[3:5])),[0.0,set()]); m[0]+=v; m[1].add(d)
    ws2=wb.create_sheet('Riepilogo')
    for i,h in enumerate(['Anno','Mese','Giorni','kWh totali'],1):
        c=ws2.cell(1,i,h); c.fill=fill; c.font=Font(bold=True,color='FFFFFF')
    for col,w in zip('ABCD',(8,14,8,14)): ws2.column_dimensions[col].width=w
    for (y,m) in sorted(mon): ws2.append([y,mn[m],len(mon[(y,m)][1]),round(mon[(y,m)][0],3)])
    tmp=xp[:-5]+'_tmp.xlsx'; wb.save(tmp); os.replace(tmp,xp)
for arg in sys.argv[1:]:
    cod,pod=arg.split(':'); name=f'{cod}_{pod}' if cod else pod
    os.makedirs(OUT,exist_ok=True); hp,qp,xp=f'{OUT}/{name}.csv',f'{OUT}/{name}_15min.csv',f'{OUT}/{name}.xlsx'
    new={}
    for f in sorted(glob.glob(f'{BASE}/download/{pod}/curva_{pod}_2*.csv')): new.update(parse(f))
    hourly={}; dropped=0
    if os.path.exists(hp):
        for l in open(hp,encoding='utf-8').read().splitlines()[1:]:
            p=l.split(';')
            if len(p)==3 and p[1].strip().isdigit() and re.match(r'\d{2}/\d{2}/\d{4}',p[0]): hourly[(p[0][:10],int(p[1]))]=fnum(p[2])
            elif l.strip(): dropped+=1
    before=len(hourly)
    for d,v in new.items():
        for h in range(24): hourly[(d,h+1)]=round(sum(v[h*4:h*4+4]),3)
    rows=sorted(hourly.items(),key=lambda kv:(dk(kv[0][0]),kv[0][1]))
    write(hp,'data;ORA;kWh\n'+''.join(f'{d} 00:00;{h};{fmt(v)}\n' for (d,h),v in rows))
    hdr='Giorno;'+';'.join(f'{i*15//60:02d}:{i*15%60:02d}-{(i+1)*15//60%24:02d}:{(i+1)*15%60:02d}' for i in range(96))
    q={}
    if os.path.exists(qp):
        ls=open(qp,encoding='utf-8').read().splitlines(); hdr=ls[0] or hdr
        for l in ls[1:]:
            if l.strip(): q[l.split(';')[0].strip().strip('"')]=l
    for d,v in new.items(): q[d]=f'"{d}";'+';'.join(f'"{fmt(x)}"' for x in v)
    write(qp,hdr+'\n'+'\n'.join(q[d] for d in sorted(q,key=dk))+'\n')
    build_xlsx({k:v for k,v in hourly.items()},xp)
    print(f'{name}: {rows[0][0][0]} - {rows[-1][0][0]} | {len(rows)} righe orarie (+{len(hourly)-before}) | {len(q)} giorni 15min'+(f' | {dropped} righe in formato non standard scartate' if dropped else ''))
```

Controllo finale (tutti i POD): ogni CSV orario deve avere `righe = giorni × 24`
e nessuna chiave `(data, ORA)` duplicata.

---

## Step 5 - Chiusura

1. Chiudi la scheda del portale (`tabs_close_mcp`).
2. **Aggiorna `data_agg`** = oggi nell'elenco per i POD aggiornati (copia di
   sicurezza in `old/` prima di salvare; non toccare i POD saltati/falliti).
3. Riepilogo finale breve: sedi aggiornate, periodo coperto, sedi con
   `⚠️` e motivo, correzioni fatte ai file, file da eliminare in
   `Download/_to_delete/`.

---

## Note tecniche (apprese in produzione)

- Download di un mese alla volta: `ExportData_<mese>.csv`, Chrome aggiunge
  ` (1)`, ` (2)` ai duplicati. Mese/anno vanno letti dai dati, non dal nome.
- Valori identici al CSV del portale (verificato byte per byte).
- Download persi ogni tanto (circa 1 ogni 30): sempre controllare il conteggio.
- Attese minime: 14 s dopo "Modifica periodo", 4,5 s dopo ogni download,
  7,5 s dopo "Successivo". Con attese piu' brevi si scarica il mese sbagliato.
- Il mese corrente non e' disponibile; il precedente di solito si'.
- Non usare pandas (memoria): solo Python puro + openpyxl.
- Nella cartella Download e nelle cartelle collegate non si cancella: sposta
  in `_to_delete/` e lascia all'utente la pulizia.
- Ordina sempre le date come `(anno, mese, giorno, ora)` interi, mai come stringhe.
